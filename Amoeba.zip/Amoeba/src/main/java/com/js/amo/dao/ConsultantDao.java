package com.js.amo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.js.amo.config.SecurityUser;
import com.js.amo.domain.Consultant;
import com.js.amo.domain.Form;
import com.js.amo.domain.User;
import com.js.amo.exception.AmoebaException;

@Repository

public interface ConsultantDao {
	
	public void saveConsultant(Consultant consultent) throws Exception; 
	
	@Select("Select * from consultant c,users u  where c.userId=u.userId")
	public List<Consultant> fetchAllConsultantById() throws AmoebaException;
	
	@Select("Select * from consultant where c_id = #{c_id}")
	public Consultant fetchConsultantById(@Param("c_id") Integer c_id) throws AmoebaException;
	
	
	//@Select("Select * from consultant c,userform u  where c.subCat=u.subCat and c.mainCat=u.mainCat and c.specialization=u.specialization and u.status=0")
	public Consultant getForms() throws AmoebaException;
	
	public List<Form> getUserForm();
	
	@Update("update userform set c_id=#{c_id}, status=1  where f_id=#{f_id}")
	public void updateForm(@Param("c_id") Integer c_id, @Param("f_id") Integer f_id)throws Exception;


}
