
package com.js.amo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.js.amo.config.SecurityUser;
import com.js.amo.dao.ConsultantDao;
import com.js.amo.domain.Consultant;
import com.js.amo.domain.Form;
import com.js.amo.domain.User;
import com.js.amo.exception.AmoebaException;

@Service
public class ConsultantService {
	
	@Autowired
	private ConsultantDao consultantDao;
	
	@Transactional
	public void saveConsultant(Consultant consultant) throws Exception{
		consultantDao.saveConsultant(consultant);
	}
	
	@Transactional
	public List<Consultant> getAllConsultant() throws AmoebaException{
		
		return consultantDao.fetchAllConsultantById();
	}
	
	@Transactional
	public Consultant getConsultantById(Integer c_id) throws AmoebaException{
		return consultantDao.fetchConsultantById(c_id);
	}

	@Transactional
	public Consultant getForms() throws AmoebaException{
		
		return consultantDao.getForms();
	}
	
	public void updateUserForm(int c_id,int  f_id) throws Exception{
		consultantDao.updateForm(c_id, f_id);
	}

	
}
