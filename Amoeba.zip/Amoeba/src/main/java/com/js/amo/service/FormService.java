package com.js.amo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.js.amo.dao.FormDao;
import com.js.amo.domain.Form;

@Service
public class FormService {
	
	@Autowired
	private FormDao formDao;
	
	
	public void saveForm(Form form) throws Exception{
		formDao.saveForm(form);
		
	}
	

}
