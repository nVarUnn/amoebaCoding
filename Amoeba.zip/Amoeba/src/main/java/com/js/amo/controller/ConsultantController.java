package com.js.amo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.js.amo.config.SecurityUser;
import com.js.amo.constants.AmoebaConstants;
import com.js.amo.domain.Consultant;
import com.js.amo.domain.User;
import com.js.amo.exception.AmoebaException;
import com.js.amo.service.ConsultantService;
import com.js.amo.service.UserService;

@RestController
@RequestMapping("/consultant")
public class ConsultantController {
	
	@Autowired
	private ConsultantService consultantService;
	
	@Autowired
	private UserService userService;
	
	private static final Logger logger=LoggerFactory.getLogger(ConsultantController.class);
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<?> saveConsultant(@RequestBody Consultant consultant,HttpServletRequest request){
		Map<String,String> map=new HashMap<>();
		
		try{
		SecurityUser securityUser=(SecurityUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		System.out.println(securityUser.getUserId());
		/*consultant.setUserId(securityUser.getUserId());
		consultantService.saveConsultant(consultant);
		System.out.println(consultant.getC_id());*/
		userService.updateUser1(securityUser,consultant);
		System.out.println(consultant.getUserId());
		map.put("SUCCESS", "Consultant Details Are Successfully Saved");
		return new ResponseEntity<Map<String,String>>(map,HttpStatus.OK);
		}catch (Exception e) {
			map.put("FAILED", "Error occured while Storing the Consultant");
			logger.error("Error occured while Saving Consultant::::", e.getMessage());
			return new ResponseEntity<Map<String,String>>(map,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	@RequestMapping(value="/getAll",method=RequestMethod.GET)
	public ResponseEntity<?> GetAllConsultants(HttpServletRequest request){
		
		try {
			return new ResponseEntity<List<Consultant>> (consultantService.getAllConsultant(), HttpStatus.OK);
		} catch (AmoebaException e) {
			logger.error("erroe wile fetching All Consultants : : :" +e.getMessage());
			return new ResponseEntity<>("Error",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@RequestMapping(value="/get/{c_id}",method=RequestMethod.GET)
	public ResponseEntity<?> GetConsultants(@PathVariable("c_id") int c_id,HttpServletRequest request) {
		
		try {
			Consultant  consultant=consultantService.getConsultantById(c_id);
			if(consultant !=null)
			return new ResponseEntity<> (consultant, HttpStatus.OK);
			return new ResponseEntity<> ("consultant not found for this id", HttpStatus.OK);
		} catch (AmoebaException e) {
			logger.error("erroe wile getting Consultants : : :" +e.getMessage());
			return new ResponseEntity<>("Error",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value="/getForms", method=RequestMethod.GET)
	public ResponseEntity<?> getForms(HttpServletRequest request){
		
		try {
			return new ResponseEntity<>(consultantService.getForms(),HttpStatus.OK);
		} catch (AmoebaException e) {
			logger.error("error getting forms"+e.getMessage());
			return new ResponseEntity<>("error",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	@RequestMapping(value="/acceptForm/{f_id}",method=RequestMethod.PUT)
	public ResponseEntity<?> updateForm(HttpServletRequest request,  @PathVariable("f_id") int f_id){
		
		Map<String,String> map=new HashMap<String,String>();
		SecurityUser user= (SecurityUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		int id=user.getUserId();
		try {
			System.out.println(id);
			consultantService.updateUserForm(id, f_id);
			map.put("success", "your Successfully Accepted Form");
			return new ResponseEntity<>(map,HttpStatus.OK);
		} catch (Exception e) {
			logger.error("getting error while updating userform"+e.getMessage());
			map.put("error", "your getting error");
			return new ResponseEntity<>(map,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		
	}
	

}
