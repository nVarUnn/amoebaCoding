package com.js.amo.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

public class Consultant {
	
	@Id
	private int c_id;
	
	private int experience;
	private String specialization;
	private String mainCat;
	private String subCat;
	private int userId;
	private Form form;
	
	private List<Form> listForms= new ArrayList<Form>();
	
	
	
	
	
	public List<Form> getListForms() {
		return listForms;
	}
	public void setListForms(List<Form> listForms) {
		this.listForms = listForms;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getMainCat() {
		return mainCat;
	}
	public void setMainCat(String mainCat) {
		this.mainCat = mainCat;
	}
	public String getSubCat() {
		return subCat;
	}
	public void setSubCat(String subCat) {
		this.subCat = subCat;
	}
	public Form getForm() {
		return form;
	}
	public void setForm(Form form) {
		this.form = form;
	}
	
	
	
	
	

}
