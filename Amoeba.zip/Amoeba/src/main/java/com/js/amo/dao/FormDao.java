package com.js.amo.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import com.js.amo.config.SecurityUser;
import com.js.amo.domain.Form;

@Repository
public interface FormDao {
	
	//@Insert("insert into userform values (age=#{age},weight=#{weight},height=#{height},specialization=#{specialization},mainCat=#{mainCat},subCat=#{subCat},user_id=#{user_id},status=#{status},c_id=#{c_id})")
	public void saveForm(Form from) throws Exception;
	
	
	

}
