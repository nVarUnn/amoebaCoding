package com.js.amo.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.js.amo.config.SecurityUser;
import com.js.amo.domain.Form;
import com.js.amo.service.FormService;

@RestController
public class FormController {
	
	@Autowired
	private FormService formService;
	
	private static final Logger logger=LoggerFactory.getLogger(FormController.class);
	
	@RequestMapping(value="/formSub",method=RequestMethod.POST)
	public ResponseEntity<?> saveForm(@RequestBody Form form, HttpServletRequest request){
		Map<String,String> map=new HashMap<>();
		try {
		SecurityUser securityUser= (SecurityUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		form.setUser_id(securityUser.getUserId());
		formService.saveForm(form);
		
		map.put("Success", "your Form is successfull submited");
		return new ResponseEntity<Map<String,String>>(map,HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("getting error while submitting form ::" +e.getMessage());
			map.put("Failur", "getting error while submitting form ");
			return new ResponseEntity<Map<String,String>>(map,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}

}
